# OpsComposer

简体中文 | [English](README.md)

该工程由 Project Forge 0.3.0 以 `fullstack` profile 生成。

Docker、局域网、Origin、Cookie、认证和环境排障见
[常见问题](FAQ.zh-CN.md)（[English](FAQ.md)）。

## 工程能力

| 能力 | 当前值 |
|---|---|
| 前端 | `true` |
| 后端 | `true` |
| 认证 | `true` |
| 事件处理 | `false` |
| 示例纵切 | `false` |
| 默认语言 | `zh-CN` |

`.project-forge.yml` 保存这组选择，`.project-forge/baseline.tar.gz` 用于受控三方更新。
不要手工修改这两个文件。

## 环境要求

- 完整工作流需要 Git、Docker Engine 和 Compose v2。
- 后端本地开发需要 Python `>=3.11` 和 uv。
- 前端本地开发需要 Node.js LTS `>=22.13 <23 || >=24 <25` 和 npm。


后端容器默认使用 Python 3.13，前端容器和生成项目 CI 默认使用 Node 24。Project Forge
覆盖 Python 3.11～3.14，以及当前受支持的 Node 22 与 Node 24 LTS。保留 Node 22 类型定义
是为了将应用代码限制在最低支持版本已有的 API 表面。奇数版本以及尚未进入 LTS 的新偶数
版本不属于兼容承诺。

提交生成基线后，执行与 profile 匹配的环境检查：

```bash
project-forge doctor .
project-forge doctor . --require-docker
```

## 使用开发 Compose 首次启动

开发栈只启动当前 profile 需要的组件，并在 API 就绪前自动应用待执行迁移。


```bash
cp .env.dev.example .env.dev
docker compose --env-file .env.dev -f docker-compose.dev.yml up --build
```

示例有效值将所有主机端口绑定到 `127.0.0.1`。局域网演示只启用注释中的前端覆盖项，替换
文档地址 `172.20.0.10`，并把该浏览器 Origin 精确加入 `DEV_APP_ALLOWED_ORIGINS`。生产
`.env` 与开发 `DEV_*` 值刻意隔离。

- 前端：[http://localhost:5173](http://localhost:5173)
- API 文档：[http://localhost:8000/docs](http://localhost:8000/docs)
- 就绪检查：[http://localhost:8000/health/ready](http://localhost:8000/health/ready)


停止服务并保留开发 volume：

```bash
docker compose --env-file .env.dev -f docker-compose.dev.yml down
```

## 运行本地进程

直接在主机运行的进程使用组件级环境文件；根目录 `.env` 专供生产 Compose。

### 后端

启动 PostgreSQL：

```bash
docker compose --env-file .env.dev -f docker-compose.dev.yml up -d db
```

在后端终端中：

```bash
cp backend/.env.example backend/.env
cd backend
uv sync --frozen --all-groups --extra auth
uv run ops-composer migrate status
uv run ops-composer migrate up
uv run ops-composer config check --json
uv run fastapi dev
```

存在待执行迁移时，API 会拒绝启动且 readiness 不通过。

认证数据维护：

```bash
cd backend
uv run ops-composer auth purge-expired --dry-run
uv run ops-composer auth purge-expired
```


### 前端

在前端终端中：

```bash
cp frontend/.env.example frontend/.env
cd frontend
npm ci
npm run dev
```

`VITE_API_BASE_URL` 默认为空，使浏览器请求保持同源；跨 Origin 配置会在启动时被拒绝。
`VITE_API_PROXY_TARGET` 控制服务端本地 Vite 代理。
PrimeVue 默认使用 Aura。页头主题控件会在浏览器中持久化跟随系统、浅色或深色模式，
并让 PrimeVue 组件与应用外壳保持一致。


## 验证

在仓库根目录运行与当前 profile 匹配的全部检查：

```bash
python harness/check.py
```

CI 严格模式会将缺失工具视为失败，并校验两份 Compose：

```bash
HARNESS_STRICT=1 HARNESS_DOCKER=1 python harness/check.py
```

后端独立门禁：

```bash
cd backend
uv run --frozen --no-sync ruff check .
uv run --frozen --no-sync mypy src/app
uv run --frozen --no-sync pytest --cov=app --cov-branch --cov-fail-under=90
uv run --frozen pip-audit
```


前端独立门禁：

```bash
cd frontend
npm run lint
npm run typecheck
npm run test:coverage
npm run build
npm run api:check
npm run i18n:check
npm audit --audit-level=high
```

### 刷新前端 API 类型

`frontend/.api-contract.json` 指向当前受跟踪的 OpenAPI 合约。有意修改 API 后，先刷新
JSON，再重新生成 TypeScript：

```bash
cd backend
uv run --frozen --no-sync python ../harness/export_openapi.py \
  ../frontend/scripts/openapi/contracts/auth.json
cd ../frontend
npm run api:generate
npm run api:check
```


## API 示例

健康检查不需要认证：

```bash
curl http://localhost:8000/health/live
curl http://localhost:8000/health/ready
```

每个 API 响应都带有 `X-Request-ID`，可用于关联脱敏后的公开错误与结构化 API 日志。
`ops-composer config check --json` 只报告不含秘密的有效设置。



创建开发用户并保存 session cookie：

```bash
curl -i -c .cookies.txt \
  -H 'Origin: http://localhost:5173' \
  -H 'Content-Type: application/json' \
  -d '{"email":"developer@example.com","password":"correct-horse-battery","workspaceName":"Personal"}' \
  http://localhost:8000/api/v1/auth/signup

curl -b .cookies.txt http://localhost:8000/api/v1/auth/session
curl -b .cookies.txt http://localhost:8000/api/v1/workspaces
```

认证后的 unsafe 请求还必须把可读 CSRF cookie 放入 `X-CSRF-Token`；生成的前端 middleware
会自动完成。


## 生产 Compose

复制根目录生产环境文件，替换全部占位值后再验证：

```bash
cp .env.example .env
docker compose config
docker compose up -d --build
```

gateway 默认绑定 `127.0.0.1:8080`，预期部署在外部 TLS terminator 后方。

生产认证会 fail closed：Origin 必须为 HTTPS、Cookie 必须 Secure、数据库 URL 和限流 secret
必须显式配置，`FORWARDED_ALLOW_IPS` 只能包含受控代理 IP/CIDR。生产环境默认关闭注册。


## 演进当前工程

仅在 Git 工作区干净时执行：

```bash
project-forge features .
project-forge doctor .
project-forge update --check .
project-forge update . --check --json
project-forge update .
project-forge configure --command-name ops-composer -C .
```

Project Forge 支持单向 `add`/`enable`，不移除能力。更新冲突会保留全部受管文件，并生成
`.rej` 供人工解决。

生成后端命令为 `ops-composer`，内部 Python 包仍为 `app`。状态 schema 3 保存该命令与
确定性模板 digest。重新安装工具来源后，`update --check` 会执行真实 dry render
和三方比较，因此公开版本不变时也能识别刷新后的模板内容：

```bash
uv tool upgrade --reinstall project-forge
git status --short
project-forge update --check .
project-forge update .
python3 harness/check.py
```

修改代码前阅读 `AGENTS.md`。架构导航见 [`docs/README.md`](docs/README.md)，其中包含
Service/UoW/Repository、SQL、迁移、i18n、认证和事件规则；运行故障见
[常见问题](FAQ.zh-CN.md)。
