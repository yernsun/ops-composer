from app.main import app
from app.settings import Settings


def test_expected_routes_are_registered_without_starting_database() -> None:
    paths = set(app.openapi()["paths"])
    assert "/health/live" in paths
    assert "/api/v1/auth/signup" in paths
    assert "/api/v1/auth/login" in paths
    assert "/api/v1/auth/session" in paths
    assert "/api/v1/auth/logout" in paths
    assert "/api/v1/workspaces" in paths
    session_schema = app.openapi()["components"]["schemas"]["SessionResponse"]["properties"]
    assert session_schema["userId"]["format"] == "uuid"
    assert session_schema["expiresAt"]["format"] == "date-time"
    workspace_schema = app.openapi()["components"]["schemas"]["WorkspaceResponse"]["properties"]
    assert workspace_schema["workspaceId"]["format"] == "uuid"
    assert workspace_schema["createdAt"]["format"] == "date-time"
    assert app.openapi()["paths"]["/api/v1/auth/signup"]["post"]["operationId"] == "signup"
    login_operation = app.openapi()["paths"]["/api/v1/auth/login"]["post"]
    assert login_operation["operationId"] == "login"
    assert {"401", "403", "429"} <= login_operation["responses"].keys()
    retry_after = login_operation["responses"]["429"]["headers"]["Retry-After"]
    assert retry_after["schema"]["type"] == "integer"




def test_settings_only_expose_enabled_capabilities() -> None:
    assert "redis_url" not in Settings.model_fields
    assert "session_cookie_secure" in Settings.model_fields
    assert "auth_rate_limit_secret" in Settings.model_fields
    assert "forwarded_allow_ips_csv" in Settings.model_fields



def test_config_cli_is_available_for_every_backend_profile() -> None:
    from click import unstyle
    from typer.testing import CliRunner

    from app.cli import app as cli_app

    result = CliRunner().invoke(cli_app, ["config", "check", "--help"])
    assert result.exit_code == 0
    assert "--json" in unstyle(result.stdout)
