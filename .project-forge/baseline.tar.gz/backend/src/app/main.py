from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.errors import install_error_handlers
from app.api.health import router as health_router
from app.api.observability import RequestContextMiddleware, configure_logging
from app.auth.api import router as auth_router
from app.db.migration_engine import MigrationRunner
from app.db.pool import create_pool
from app.db.registry import MIGRATIONS
from app.settings import get_settings
from app.uow.factory import UnitOfWorkFactory


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    pool = create_pool(settings.database_url)
    await pool.open()
    try:
        async with pool.connection() as connection:
            await MigrationRunner(connection, MIGRATIONS).validate_current()
        app.state.database_pool = pool
        app.state.unit_of_work_factory = UnitOfWorkFactory(pool)
        yield
    finally:
        await pool.close()


def create_app() -> FastAPI:
    configure_logging()
    application = FastAPI(
        title="OpsComposer API",
        version="0.1.0",
        lifespan=lifespan,
    )
    application.add_middleware(RequestContextMiddleware)
    application.include_router(health_router)
    application.include_router(auth_router)
    install_error_handlers(application)
    return application


app = create_app()
