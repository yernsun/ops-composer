from __future__ import annotations

import asyncio
import sys
from contextlib import AsyncExitStack
from functools import cached_property
from types import TracebackType

from app.auth.repository import PostgresAuthRepository
from app.db.registry import MIGRATIONS
from app.db.repository_connection import PsycopgRepositoryConnection
from app.db.types import DbPool
from app.repositories.base import RepositoryConnection
from app.repositories.health import PostgresHealthRepository

EXPECTED_MIGRATION_CHECKSUMS = {
    migration.migration_id: migration.checksum for migration in MIGRATIONS
}


class UnitOfWork:
    """One pooled transaction, one task, one use, and lazy repositories."""

    def __init__(self, pool: DbPool) -> None:
        self._pool = pool
        self._contexts = AsyncExitStack()
        self._repository_connection: PsycopgRepositoryConnection | None = None
        self._owner: asyncio.Task[object] | None = None
        self._entered = False
        self._closed = False

    async def __aenter__(self) -> UnitOfWork:
        if self._entered or self._closed:
            raise RuntimeError("UnitOfWork instances are single-use")
        owner = asyncio.current_task()
        if owner is None:
            raise RuntimeError("UnitOfWork requires an active asyncio task")
        self._owner = owner
        self._entered = True
        try:
            connection = await self._contexts.enter_async_context(self._pool.connection())
            await self._contexts.enter_async_context(connection.transaction())
            self._repository_connection = PsycopgRepositoryConnection(connection, owner)
            return self
        except BaseException:
            self._closed = True
            await self._contexts.__aexit__(*sys.exc_info())
            raise

    def assert_owner(self) -> None:
        if not self._entered or self._closed:
            raise RuntimeError("UnitOfWork is not active")
        if asyncio.current_task() is not self._owner:
            raise RuntimeError("UnitOfWork cannot cross asyncio task boundaries")

    def _require_connection(self) -> RepositoryConnection:
        self.assert_owner()
        connection = self._repository_connection
        if connection is None:
            raise RuntimeError("UnitOfWork repository connection was not initialized")
        return connection

    @cached_property
    def health(self) -> PostgresHealthRepository:
        """Return migration-aware readiness persistence for this transaction."""

        return PostgresHealthRepository(
            self._require_connection(),
            expected_migrations=EXPECTED_MIGRATION_CHECKSUMS,
        )

    @cached_property
    def auth(self) -> PostgresAuthRepository:
        """Return authentication persistence for this transaction."""

        return PostgresAuthRepository(self._require_connection())

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.assert_owner()
        repository_connection = self._repository_connection
        self._closed = True
        if repository_connection is not None:
            repository_connection.finish()
        try:
            await self._contexts.__aexit__(exc_type, exc_value, traceback)
        finally:
            self._repository_connection = None
