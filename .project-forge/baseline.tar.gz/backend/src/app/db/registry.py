from app.db.migration_engine import Migration
from app.db.migrations.auth import AUTH
from app.db.migrations.auth_security import AUTH_SECURITY
from app.db.migrations.core import CORE

MIGRATIONS: tuple[Migration, ...] = (
    CORE,
    AUTH,
    AUTH_SECURITY,

)
