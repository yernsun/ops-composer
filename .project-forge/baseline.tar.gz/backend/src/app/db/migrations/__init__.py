"""Immutable migration definitions."""
