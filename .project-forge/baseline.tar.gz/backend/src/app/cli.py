from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Annotated

import typer
from pydantic import ValidationError

from app.auth.service import AuthService
from app.db.migration_engine import MigrationRunner
from app.db.pool import create_pool
from app.db.registry import MIGRATIONS
from app.settings import Settings, get_settings
from app.uow.factory import UnitOfWorkFactory

app = typer.Typer(no_args_is_help=True)
migrate = typer.Typer(help="Manage the immutable migration DAG")
app.add_typer(migrate, name="migrate")
configuration = typer.Typer(help="Validate and inspect redacted runtime configuration")
app.add_typer(configuration, name="config")
auth = typer.Typer(help="Operate authentication persistence")
app.add_typer(auth, name="auth")



def _safe_configuration_errors(error: ValidationError) -> list[dict[str, str]]:
    """Serialize validation failures without environment values or exception context."""

    errors: list[dict[str, str]] = []
    for detail in error.errors(include_url=False, include_context=False, include_input=False):
        location = ".".join(str(part) for part in detail.get("loc", ())) or "settings"
        errors.append(
            {
                "location": location,
                "type": str(detail.get("type", "validation_error")),
                "message": str(detail.get("msg", "invalid value")),
            }
        )
    return errors


@asynccontextmanager
async def _runner() -> AsyncIterator[MigrationRunner]:
    settings = get_settings()
    pool = create_pool(settings.database_url)
    await pool.open()
    try:
        async with pool.connection() as connection:
            yield MigrationRunner(connection, MIGRATIONS)
    finally:
        await pool.close()


@migrate.command("status")
def migration_status() -> None:
    async def run() -> None:
        async with _runner() as runner:
            for entry in await runner.status():
                typer.echo(f"{entry.state.value:8} {entry.migration_id} {entry.checksum[:12]}")

    asyncio.run(run())


@configuration.command("check")
def configuration_check(
    as_json: Annotated[bool, typer.Option("--json", help="Emit machine-readable JSON")] = False,
) -> None:
    """Validate effective settings and print only non-secret values."""

    try:
        summary = Settings().safe_summary()
    except ValidationError as error:
        errors = _safe_configuration_errors(error)
        if as_json:
            typer.echo(json.dumps({"ok": False, "errors": errors}, sort_keys=True))
        else:
            typer.secho("configuration invalid", fg=typer.colors.RED, err=True)
            for detail in errors:
                typer.echo(
                    f"- {detail['location']}: {detail['message']} ({detail['type']})",
                    err=True,
                )
        raise typer.Exit(code=2) from error
    if as_json:
        typer.echo(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return
    typer.echo(f"environment={summary['environment']}")
    typer.echo(f"database_configured={str(summary['database_configured']).lower()}")
    authentication = summary["authentication"]
    if not isinstance(authentication, dict):  # pragma: no cover - safe_summary invariant
        raise RuntimeError("authentication summary is invalid")
    typer.echo("allowed_origins=" + ",".join(authentication["allowed_origins"]))
    typer.echo(f"cookies_secure={str(authentication['cookies_secure']).lower()}")
    typer.echo(f"signup_enabled={str(authentication['signup_enabled']).lower()}")
    typer.echo("trusted_proxies=" + ",".join(authentication["trusted_proxies"]))



@migrate.command("validate")
def migration_validate() -> None:
    async def run() -> None:
        async with _runner() as runner:
            await runner.validate()

    asyncio.run(run())
    typer.echo("migration history is valid")


@migrate.command("up")
def migration_up() -> None:
    async def run() -> tuple[str, ...]:
        async with _runner() as runner:
            return await runner.up()

    applied = asyncio.run(run())
    typer.echo("applied: " + (", ".join(applied) if applied else "none"))


@auth.command("purge-expired")
def auth_purge_expired(
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Count expired rows without deleting them"),
    ] = False,
) -> None:
    """Delete expired sessions and fixed-window rate-limit rows."""

    async def run() -> tuple[int, int]:
        settings = get_settings()
        pool = create_pool(settings.database_url)
        await pool.open()
        try:
            service = AuthService(UnitOfWorkFactory(pool), settings)
            return await service.purge_expired(dry_run=dry_run)
        finally:
            await pool.close()

    sessions, rate_limits = asyncio.run(run())
    action = "would_purge" if dry_run else "purged"
    typer.echo(f"{action} sessions={sessions} rate_limits={rate_limits}")

def main() -> None:
    app()
