from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STRICT = os.getenv("HARNESS_STRICT") == "1"


def run(
    command: list[str], cwd: Path = ROOT, *, env: dict[str, str] | None = None
) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True, env=env)


def require(tool: str) -> bool:
    found = shutil.which(tool) is not None
    if not found and STRICT:
        raise RuntimeError(f"required tool is missing: {tool}")
    if not found:
        print(f"skip: {tool} is not installed")
    return found


def _run_checks() -> int:
    run([sys.executable, "harness/check_architecture.py"])
    run([sys.executable, "harness/check_sql.py"])
    run([sys.executable, "harness/check_i18n.py"])
    backend = ROOT / "backend"
    if backend.exists() and require("uv"):
        sync = ["uv", "sync", "--frozen", "--all-groups"]
        if (backend / "src/app/auth").exists():
            sync.extend(["--extra", "auth"])
        if (backend / "src/app/events").exists():
            sync.extend(["--extra", "evented"])
        run(sync, backend)
        run(
            ["uv", "run", "--frozen", "--no-sync", "ops-composer", "--help"],
            backend,
        )
        run(["uv", "run", "--frozen", "--no-sync", "ruff", "check", "."], backend)
        run(["uv", "run", "--frozen", "--no-sync", "mypy", "src/app"], backend)
        pytest = ["uv", "run", "--frozen", "--no-sync", "pytest"]
        if STRICT:
            pytest.extend(
                [
                    "--cov=app",
                    "--cov-branch",
                    "--cov-report=term-missing",
                    "--cov-fail-under=90",
                ]
            )
        run(pytest, backend)
    frontend = ROOT / "frontend"
    if frontend.exists() and require("npm"):
        install = ["npm", "ci"] if (frontend / "package-lock.json").exists() else ["npm", "install"]
        run(install, frontend)
        test_script = "test:coverage" if STRICT else "test"
        for script in ("lint", "typecheck", test_script, "build"):
            run(["npm", "run", script], frontend)
    if backend.exists() and frontend.exists() and require("uv") and require("npm"):
        with tempfile.TemporaryDirectory(prefix="project-forge-openapi-") as temp_dir:
            contract = Path(temp_dir) / "openapi.json"
            run(
                [
                    "uv",
                    "run",
                    "--frozen",
                    "--no-sync",
                    "python",
                    "../harness/export_openapi.py",
                    str(contract),
                ],
                backend,
            )
            run(
                [
                    "node",
                    "scripts/generate-api.mjs",
                    "--check",
                    "--source",
                    str(contract),
                ],
                frontend,
            )
    if os.getenv("HARNESS_DOCKER") == "1" and require("docker"):
        with tempfile.TemporaryDirectory(prefix="project-forge-compose-") as temp_dir:
            compose_environment = Path(temp_dir) / "compose.env"
            compose_environment.write_text(
                "\n".join(
                    (
                        "POSTGRES_PASSWORD=harness-only-database-password",
                        "DATABASE_URL=postgresql://app:harness-only-database-password@db:5432/app",
                        "APP_ALLOWED_ORIGINS=https://172.20.0.10:8443",
                        "APP_AUTH_RATE_LIMIT_SECRET=harness-only-rate-limit-secret-at-least-32-bytes",
                        "APP_SIGNUP_ENABLED=false",
                        "FORWARDED_ALLOW_IPS=127.0.0.1",
                        "FRONTEND_API_UPSTREAM=http://host.docker.internal:8000",
                        "FRONTEND_API_PROXY_TARGET=http://host.docker.internal:8000",
                    )
                )
                + "\n",
                encoding="utf-8",
            )
            compose_process_environment = os.environ.copy()
            for name in (
                "POSTGRES_PASSWORD",
                "DATABASE_URL",
                "APP_ALLOWED_ORIGINS",
                "APP_AUTH_RATE_LIMIT_SECRET",
                "APP_SIGNUP_ENABLED",
                "FORWARDED_ALLOW_IPS",
                "APP_BIND_HOST",
                "APP_PORT",
                "FRONTEND_API_UPSTREAM",
                "FRONTEND_API_PROXY_TARGET",
            ):
                compose_process_environment.pop(name, None)
            for compose_file in ("docker-compose.dev.yml", "docker-compose.yml"):
                run(
                    [
                        "docker",
                        "compose",
                        "--env-file",
                        str(compose_environment),
                        "-f",
                        compose_file,
                        "config",
                    ],
                    env=compose_process_environment,
                )
    return 0


def main() -> int:
    try:
        return _run_checks()
    except subprocess.CalledProcessError as error:
        return error.returncode if error.returncode > 0 else 1
    except RuntimeError as error:
        print(f"harness error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
