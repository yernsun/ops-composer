<script setup lang="ts">
import Button from 'primevue/button'
import Message from 'primevue/message'
import ProgressSpinner from 'primevue/progressspinner'
import { usePrimeVue } from 'primevue/config'
import { onBeforeUnmount, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'

import AuthPanel from '@/features/auth/AuthPanel.vue'
import { useSessionState } from '@/features/auth/session'
import WorkspaceSwitcher from '@/features/auth/WorkspaceSwitcher.vue'

import { supportedLocales, type AppLocale } from '@/shared/i18n'
import { useLocaleStore } from '@/shared/stores/locale'
import { useThemeStore } from '@/shared/stores/theme'
import { themePreferences, type ThemePreference } from '@/shared/theme'

const { t } = useI18n()
const localeStore = useLocaleStore()
const themeStore = useThemeStore()
const primeVue = usePrimeVue()
const { sessionQuery, session, state: authState } = useSessionState()


onMounted(themeStore.start)
onBeforeUnmount(themeStore.stop)

function changeLocale(event: Event): void {
  const next = (event.target as HTMLSelectElement).value as AppLocale
  localeStore.setLocale(next, primeVue)
}

function changeTheme(event: Event): void {
  const next = (event.target as HTMLSelectElement).value as ThemePreference
  themeStore.setTheme(next)
}
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div>
        <p class="eyebrow">OpsComposer</p>
        <h1 v-text="t('app.title')" />
        <p class="subtitle" v-text="t('app.subtitle')" />
      </div>
      <div class="preference-controls">
        <label class="preference-control locale-control">
          <span v-text="t('app.language')" />
          <select :value="localeStore.locale" @change="changeLocale">
            <option
              v-for="locale in supportedLocales"
              :key="locale"
              :value="locale"
              v-text="t(`locales.${locale}`)"
            />
          </select>
        </label>
        <label class="preference-control theme-control">
          <span v-text="t('app.theme')" />
          <select :value="themeStore.preference" @change="changeTheme">
            <option
              v-for="theme in themePreferences"
              :key="theme"
              :value="theme"
              v-text="t(`themes.${theme}`)"
            />
          </select>
        </label>
      </div>
    </header>
    <main>
      <section v-if="sessionQuery.isError.value" class="content-card auth-status" role="alert">
        <Message severity="error" :closable="false"><span v-text="t('auth.errors.session_failed')" /></Message>
        <Button
          icon="pi pi-refresh"
          :label="t('app.retry')"
          @click="sessionQuery.refetch()"
        />
      </section>
      <section v-else-if="authState === 'loading'" class="content-card auth-status" aria-live="polite">
        <ProgressSpinner class="auth-spinner" stroke-width="5" />
        <p v-text="t('auth.restoringSession')" />
      </section>
      <AuthPanel v-else-if="authState === 'guest'" />
      <template v-else-if="session">
        <WorkspaceSwitcher :session="session" />
        <section class="hero-card">
          <span class="status-dot" aria-hidden="true" />
          <p v-text="t('app.ready')" />
          <Button :label="t('app.ready')" icon="pi pi-check" disabled />
        </section>
      </template>
    </main>
  </div>
</template>
