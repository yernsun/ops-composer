import createClient, { type Middleware } from 'openapi-fetch'

import type { paths, components } from './schema'


export const AUTH_UNAUTHORIZED_EVENT = 'project-forge:auth-unauthorized'


export type LoginDto = components['schemas']['LoginRequest']
export type SignupDto = components['schemas']['SignupRequest']
export type SessionDto = components['schemas']['SessionResponse']
export type WorkspaceDto = components['schemas']['WorkspaceResponse']

export class ApiRequestError extends Error {
  readonly status: number
  readonly code: string
  readonly retryAfter: number | null

  constructor(status: number, code: string, message: string, retryAfter: number | null = null) {
    super(message)
    this.name = 'ApiRequestError'
    this.status = status
    this.code = code
    this.retryAfter = retryAfter
  }
}

function cookie(name: string): string | null {
  const prefix = `${encodeURIComponent(name)}=`
  const entry = document.cookie.split(';').map((value) => value.trim()).find((value) => value.startsWith(prefix))
  if (!entry) return null
  try {
    return decodeURIComponent(entry.slice(prefix.length))
  } catch {
    return null
  }
}

export function readCsrfToken(): string | null {
  return cookie('__Host-ops-composer-csrf') ?? cookie('ops-composer-csrf')
}


type ApiErrorDetails = Pick<ApiRequestError, 'code' | 'message'>

function errorDetails(value: unknown): ApiErrorDetails | null {
  if (typeof value !== 'object' || value === null) return null
  const candidate = value as Partial<ApiErrorDetails>
  return typeof candidate.code === 'string' && typeof candidate.message === 'string'
    ? { code: candidate.code, message: candidate.message }
    : null
}

function requestError(response: Response, error: unknown, fallbackCode: string): ApiRequestError {
  const details = errorDetails(error)
  const retryAfter = Number.parseInt(response.headers.get('Retry-After') ?? '', 10)
  return new ApiRequestError(
    response.status,
    details?.code ?? fallbackCode,
    details?.message ?? fallbackCode,
    Number.isFinite(retryAfter) ? retryAfter : null,
  )
}


export function resolveApiBaseUrl(
  configured: string | undefined,
  browserOrigin: string = window.location.origin,
): string {
  const value = (configured ?? '').trim()
  if (!value) return browserOrigin
  const resolved = new URL(value, browserOrigin)
  if (resolved.origin !== browserOrigin) {
    throw new Error('VITE_API_BASE_URL must resolve to the browser origin; use the gateway or Vite proxy')
  }
  return resolved.href.replace(/\/$/, '')
}

const configuredBaseUrl = resolveApiBaseUrl(import.meta.env.VITE_API_BASE_URL)
const client = createClient<paths>({
  baseUrl: configuredBaseUrl,
  credentials: 'include',
  fetch: (request) => globalThis.fetch(request),
})


const sessionMiddleware: Middleware = {
  async onRequest({ request }) {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method)) {
      const token = readCsrfToken()
      if (token && !request.headers.has('X-CSRF-Token')) request.headers.set('X-CSRF-Token', token)
    }
    return request
  },
  async onResponse({ response }) {
    if (response.status === 401) window.dispatchEvent(new CustomEvent(AUTH_UNAUTHORIZED_EVENT))
    return response
  },
}

client.use(sessionMiddleware)


export async function signup(input: SignupDto): Promise<SessionDto> {
  const { data, error, response } = await client.POST('/api/v1/auth/signup', { body: input })
  if (error || !data) throw requestError(response, error, 'signup_failed')
  return data
}

export async function login(input: LoginDto): Promise<SessionDto> {
  const { data, error, response } = await client.POST('/api/v1/auth/login', { body: input })
  if (error || !data) throw requestError(response, error, 'login_failed')
  return data
}

export async function getSession(): Promise<SessionDto | null> {
  const { data, error, response } = await client.GET('/api/v1/auth/session')
  if (response.status === 401) return null
  if (error || !data) throw requestError(response, error, 'session_failed')
  return data
}

export async function logout(): Promise<void> {
  const { error, response } = await client.POST('/api/v1/auth/logout')
  if (error) throw requestError(response, error, 'logout_failed')
}

export async function listWorkspaces(): Promise<WorkspaceDto[]> {
  const { data, error, response } = await client.GET('/api/v1/workspaces')
  if (error || !data) throw requestError(response, error, 'workspaces_failed')
  return data.workspaces
}

export async function createWorkspace(name: string): Promise<WorkspaceDto> {
  const { data, error, response } = await client.POST('/api/v1/workspaces', {
    body: { name },
  })
  if (error || !data) throw requestError(response, error, 'workspace_create_failed')
  return data
}

